package com.tns.fooddelivery;



import java.util.*;

public class FoodDeliverySystem {
    static Scanner sc = new Scanner(System.in);
    static Map<Integer, Restaurant> restaurants = new HashMap<>();
    static Map<Integer, Customer> customers = new HashMap<>();
    static List<DeliveryPerson> deliveryPeople = new ArrayList<>();
    static List<Order> orders = new ArrayList<>();

    static AdminService adminService = new AdminService(restaurants, deliveryPeople);
    static CustomerService customerService = new CustomerService(customers);
    static OrderService orderService = new OrderService(orders);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Admin Menu\n2. Customer Menu\n3. Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:adminMenu();
                case 2: customerMenu();
                case 3: {
                    System.out.println("Exiting...");
                    return;
                }
            }
        }
    }

    static void adminMenu() {
        while (true) {
            System.out.println("\nAdmin Menu:");
            System.out.println("1. Add Restaurant\n2. Add Food Item\n3. Remove Food Item\n4. View Restaurants");
            System.out.println("5. Add Delivery Person\n6. Assign Delivery to Order\n7. View Orders\n8. Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:{
                    System.out.print("Restaurant ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Restaurant Name: ");
                    String name = sc.nextLine();
                    adminService.addRestaurant(id, name);
                }
                case 2: {
                    System.out.print("Restaurant ID: ");
                    int rid = sc.nextInt();
                    System.out.print("Food ID: ");
                    int fid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String fname = sc.nextLine();
                    System.out.print("Price: ");
                    double price = sc.nextDouble();
                    adminService.addFoodItemToRestaurant(rid, new FoodItem(fid, fname, price));
                }
                case 3: {
                    System.out.print("Restaurant ID: ");
                    int rid = sc.nextInt();
                    System.out.print("Food ID to remove: ");
                    int fid = sc.nextInt();
                    adminService.removeFoodItemFromRestaurant(rid, fid);
                }
                case 4: adminService.viewRestaurants();
                case 5:{
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Contact No.: ");
                    long contact = sc.nextLong();
                    adminService.addDeliveryPerson(id, name, contact);
                }
                case 6: {
                    System.out.print("Order ID: ");
                    int oid = sc.nextInt();
                    System.out.print("Delivery Person ID: ");
                    int did = sc.nextInt();
                    adminService.assignDeliveryPersonToOrder(orders, oid, did);
                }
                case 7: adminService.viewOrders(orders);
                case 8: { return; }
            }
        }
    }

    static void customerMenu() {
        Customer customer = null;
        while (true) {
            System.out.println("\nCustomer Menu:");
            System.out.println("1. Register\n2. View Food Items\n3. Add to Cart\n4. View Cart\n5. Place Order\n6. View Orders\n7. Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1: {
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Contact: ");
                    long contact = sc.nextLong();
                    customer = customerService.registerCustomer(id, name, contact);
                }
                case 2: {
                    if (restaurants.isEmpty()) {
                        System.out.println("No restaurants available.");
                    } else {
                        for (Restaurant r : restaurants.values()) {
                            System.out.println(r);
                        }
                    }
                }
                case 3: {
                    if (customer == null) {
                        System.out.println("Please register first.");
                        break;
                    }
                    System.out.print("Restaurant ID: ");
                    int rid = sc.nextInt();
                    Restaurant r = restaurants.get(rid);
                    if (r == null) {
                        System.out.println("Restaurant not found.");
                        break;
                    }
                    System.out.print("Food ID: ");
                    int fid = sc.nextInt();
                    FoodItem selected = null;
                    for (FoodItem f : r.getMenu()) {
                        if (f.getId() == fid) {
                            selected = f;
                            break;
                        }
                    }
                    if (selected == null) {
                        System.out.println("Food not found.");
                        break;
                    }
                    System.out.print("Quantity: ");
                    int qty = sc.nextInt();
                    customer.getCart().addItem(selected, qty);
                    System.out.println("Item added to cart.");
                }
                case 4: {
                    if (customer != null) System.out.println(customer.getCart());
                    else System.out.println("Please register first.");
                }
                case 5: {
                    if (customer != null) {
                        sc.nextLine();
                        System.out.print("Delivery Address: ");
                        String address = sc.nextLine();
                        orderService.placeOrder(customer, address);
                    } else System.out.println("Please register first.");
                }
                case 6: {
                    if (customer != null) orderService.viewCustomerOrders(customer);
                    else System.out.println("Please register first.");
                }
                case 7: { return; }
            }
        }
    }
}

