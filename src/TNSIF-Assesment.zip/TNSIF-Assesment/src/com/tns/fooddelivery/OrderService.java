package com.tns.fooddelivery;



import java.util.List;

public class OrderService {
    private List<Order> orders;

    public OrderService(List<Order> orders) {
        this.orders = orders;
    }

    public void placeOrder(Customer customer, String address) {
        if (customer.getCart().getItems().isEmpty()) {
            System.out.println("Cart is empty!");
            return;
        }
        Order order = new Order(customer, address);
        orders.add(order);
        customer.getCart().clear();
        System.out.println("Order placed successfully! Order ID: " + order.getOrderId());
    }

    public void viewCustomerOrders(Customer customer) {
        for (Order o : orders) {
            if (o.toString().contains(customer.getUsername()))
                System.out.println(o);
        }
    }
}

