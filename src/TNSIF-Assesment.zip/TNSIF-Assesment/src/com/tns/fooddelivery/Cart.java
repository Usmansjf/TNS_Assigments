package com.tns.fooddelivery;



import java.util.*;

public class Cart {
    private Map<FoodItem, Integer> items = new HashMap<>();

    public void addItem(FoodItem item, int quantity) {
        items.put(item, items.getOrDefault(item, 0) + quantity);
    }

    public void removeItem(FoodItem item) {
        items.remove(item);
    }

    public Map<FoodItem, Integer> getItems() { return items; }

    public void clear() { items.clear(); }

    public String toString() {
        if (items.isEmpty()) return "Cart is empty.";
        StringBuilder sb = new StringBuilder("Cart:\n");
        for (Map.Entry<FoodItem, Integer> entry : items.entrySet()) {
            sb.append("- ").append(entry.getKey().getName())
              .append(", Quantity: ").append(entry.getValue())
              .append(", Cost: Rs. ").append(entry.getKey().getPrice() * entry.getValue()).append("\n");
        }
        return sb.toString();
    }
}
