package com.tns.fooddelivery;


import java.util.*;

public class AdminService {
    private Map<Integer, Restaurant> restaurants;
    private List<DeliveryPerson> deliveryPeople;

    public AdminService(Map<Integer, Restaurant> restaurants, List<DeliveryPerson> deliveryPeople) {
        this.restaurants = restaurants;
        this.deliveryPeople = deliveryPeople;
    }

    public void addRestaurant(int id, String name) {
        restaurants.put(id, new Restaurant(id, name));
    }

    public void addFoodItemToRestaurant(int restId, FoodItem item) {
        Restaurant r = restaurants.get(restId);
        if (r != null) r.addFoodItem(item);
    }

    public void removeFoodItemFromRestaurant(int restId, int foodId) {
        Restaurant r = restaurants.get(restId);
        if (r != null) r.removeFoodItem(foodId);
    }

    public void viewRestaurants() {
        for (Restaurant r : restaurants.values()) {
            System.out.println(r);
        }
    }

    public void addDeliveryPerson(int id, String name, long contact) {
        deliveryPeople.add(new DeliveryPerson(id, name, contact));
    }

    public void assignDeliveryPersonToOrder(List<Order> orders, int orderId, int dpId) {
        for (Order o : orders) {
            if (o.getOrderId() == orderId) {
                for (DeliveryPerson dp : deliveryPeople) {
                    if (dp.getId() == dpId) {
                        o.setDeliveryPerson(dp);
                        System.out.println("Delivery person assigned.");
                        return;
                    }
                }
            }
        }
        System.out.println("Order or Delivery person not found.");
    }

    public void viewOrders(List<Order> orders) {
        for (Order o : orders) System.out.println(o);
    }
}
